<?php
// Admin directory index file
// Redirect to login page
header('Location: ./login.php');
exit;
?>
