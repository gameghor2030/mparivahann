<?php
// Redirect to admin login page
header('Location: ./admin/login.php');
exit;
?>
